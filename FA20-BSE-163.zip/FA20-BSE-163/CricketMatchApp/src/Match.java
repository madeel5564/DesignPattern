// Match class
public class Match {
    private String matchId;
    private String team1;
    private String team2;
    private String matchStatus;
    private Score score;
    private BallByBallCoverage ballByBallCoverage;

    // Getters and setters...

    // Other methods specific to Match...

    String getMatchId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    boolean getTeam2() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getTeam1() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Object getBallByBallCoverage() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
