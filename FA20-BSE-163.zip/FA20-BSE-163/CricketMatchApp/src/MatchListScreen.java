import java.util.List;

// MatchListScreen class (Observer)
public class MatchListScreen implements Observer {
    private CricketMatchApp cricketMatchApp;

    public MatchListScreen(CricketMatchApp cricketMatchApp) {
        this.cricketMatchApp = cricketMatchApp;
        cricketMatchApp.addObserver(this);
    }

    @Override
    public void update() {
        // Update match list when notified by CricketMatchApp
        List<Match> matchList = cricketMatchApp.getLiveMatches();
        displayMatchList(matchList);
    }

    public void displayMatchList(List<Match> matchList) {
        System.out.println("Live Matches:");
        for (Match match : matchList) {
            System.out.println("Match ID: " + match.getMatchId());
            System.out.println("Teams: " + match.getTeam1() + " vs " + match.getTeam2());
            // Display other match details as needed
            System.out.println();
        }
    }
}
