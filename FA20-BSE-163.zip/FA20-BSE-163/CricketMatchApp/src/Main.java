public class Main {
    public static void main(String[] args) {
        CricketMatchApp cricketApp = new CricketMatchApp();
        MatchListScreen matchListScreen = new MatchListScreen(cricketApp);
        MatchDetailsScreen matchDetailsScreen = new MatchDetailsScreen(cricketApp);

        // Add some live matches
        Match match1 = new Match(/* match details */);
        cricketApp.addLiveMatch(match1);

        Match match2 = new Match(/* match details */);
        cricketApp.addLiveMatch(match2);

        // Simulate selecting a match (this will trigger the update in MatchDetailsScreen)
        matchDetailsScreen.update();
    }
}












Live Matches:
Match ID: 1
Teams: TeamA vs TeamB

Ball-by-Ball Coverage for Match ID: 1
Innings: 1st Innings
Batsman: Player1
Bowler: Player2