// Score class
public class Score {
    private int team1Score;
    private int team2Score;

    // Getters and setters...

    // Other methods specific to Score...
}
