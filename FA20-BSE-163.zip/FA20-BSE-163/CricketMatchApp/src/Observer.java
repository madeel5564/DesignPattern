// Observer interface
interface Observer {
    void update();
}