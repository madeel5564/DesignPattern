// MatchDetailsScreen class (Observer)
public class MatchDetailsScreen implements Observer {
    private CricketMatchApp cricketMatchApp;
    private Match selectedMatch;

    public MatchDetailsScreen(CricketMatchApp cricketMatchApp) {
        this.cricketMatchApp = cricketMatchApp;
        cricketMatchApp.addObserver(this);
    }

    @Override
    public void update() {
        // Assuming you have logic to select a match (e.g., user interaction)
        // For simplicity, let's assume the first match in the list is selected
        List<Match> matchList = (List<Match>) cricketMatchApp.getLiveMatches();

        if (!matchList.isEmpty()) {
            this.selectedMatch = matchList.get(0);
            showBallByBallCoverage();
        }
    }

    public void showBallByBallCoverage() {
        if (selectedMatch != null) {
            // Display ball-by-ball coverage for the selected match
            System.out.println("Ball-by-Ball Coverage for Match ID: " + selectedMatch.getMatchId());
            // Implement the display of ball-by-ball coverage details
           // System.out.println("Innings: " + selectedMatch.getBallByBallCoverage().getInnings());
           // System.out.println("Batsman: " + selectedMatch.getBallByBallCoverage().getBatsman());
           // System.out.println("Bowler: " + selectedMatch.getBallByBallCoverage().getBowler());
            // Display other ball-by-ball coverage details as needed
            System.out.println();
        } else {
            System.out.println("No selected match to display.");
        }
    }
}
