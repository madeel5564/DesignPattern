import java.util.ArrayList;
import java.util.List;

// CricketMatchApp class (Subject)
public class CricketMatchApp implements Subject {
    private List<Observer> observers = new ArrayList<>();
    private List<Match> liveMatches = new ArrayList<>();

    public void addLiveMatch(Match match) {
        liveMatches.add(match);
        notifyObservers();
    }

    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update();
        }
    }

    public List<Match> getLiveMatches() {
        return liveMatches;
    }
}
