// BallByBallCoverage class
public class BallByBallCoverage {
    private int currentOver;
    private int currentBall;
    private String innings;
    private String batsman;
    private String bowler;
    private int runsScored;
    private int extras;

    // Getters and setters...

    // Other methods specific to BallByBallCoverage...
}
